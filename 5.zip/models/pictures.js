var Schema = require('mongoose').Schema;
var db = require('../config/db');

var Picture = db.model('Pictures', {
    name: String,
    status: String,
    current_price: String,
    starting_date: Number,
    ending_date: Number,
    rating: Number
});

module.exports = Picture;
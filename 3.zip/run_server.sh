nodemon index.js 

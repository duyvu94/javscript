var express = require('express');
var app = express();
var bodyParser = require('body-parser');

app.use(express.static('static'));

require('./routes/userlist')(app);
require('./routes/picturelist')(app);
require('./routes/outside')(app);

var server = app.listen(3000, function () {
    console.log("1.1.0");
});
var mainRedirectMW = require('../middleware/generic/mainRedirect');
var inverseAuthMW = require('../middleware/generic/inverseAuth');
var checkUserLoginMW = require('../middleware/users/checkUserLogin');
var renderMW = require('../middleware/generic/render');
var authMW = require('../middleware/generic/auth');
var logoutMW = require('../middleware/generic/logout');
var usersModel = require('../models/users');

module.exports = function (app) {

    var objectRepository = {
        usersModel: usersModel
    };

    /**
     * Main page
     */
    app.get('/',
        mainRedirectMW(objectRepository)
    );

    /**
     * Bidding page
     */
    app.get('/main',
        authMW(objectRepository),
        renderMW(objectRepository, 'main')
    );

    /**
     * private page
     */
    app.get('/privateSite',
        authMW(objectRepository),
        renderMW(objectRepository, 'privateSite')
    );

    /**
     * Login and Registration page
     */
    app.use('/login',
        inverseAuthMW(objectRepository),
        checkUserLoginMW(objectRepository),
        renderMW(objectRepository, 'login')
    );

    /**
     * Main page
     */
    app.get('/logout',
        logoutMW(objectRepository),
        function(req, res, next) {
            res.redirect('/');
        }
    );

};
